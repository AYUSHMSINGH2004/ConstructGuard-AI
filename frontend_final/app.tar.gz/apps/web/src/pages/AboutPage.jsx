
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Brain, Sparkles, Eye, Shield, Zap, TrendingUp } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import FeatureCard from '@/components/FeatureCard.jsx';

const AboutPage = () => {
  const technologies = [
    {
      icon: Brain,
      title: 'Cascaded Neural Networks',
      description: 'Multi-stage convolutional architectures trained on proprietary engineering datasets. Advanced feature extraction for micro-fracture and anomaly isolation.'
    },
    {
      icon: Sparkles,
      title: 'LLM Report Synthesis',
      description: 'Generative models parse visual vectors to draft authoritative diagnostic text, including root cause hypotheses and standard remediation protocol.'
    },
    {
      icon: Eye,
      title: 'Model Interpretability',
      description: 'GradCAM spatial mapping highlights exact pixel clusters influencing classification, ensuring absolute transparency in automated decisioning.'
    }
  ];

  const classificationReport = [
    { class: 'Algal growth', precision: 0.72, recall: 0.68, f1: 0.70, support: 105 },
    { class: 'Major fracture', precision: 0.81, recall: 0.75, f1: 0.78, support: 98 },
    { class: 'Hairline stress', precision: 0.75, recall: 0.80, f1: 0.77, support: 110 },
    { class: 'Fungal colonies', precision: 0.69, recall: 0.71, f1: 0.70, support: 95 },
    { class: 'Coating failure', precision: 0.78, recall: 0.74, f1: 0.76, support: 102 },
    { class: 'Verified baseline', precision: 0.85, recall: 0.88, f1: 0.86, support: 120 },
    { class: 'Concrete spalling', precision: 0.73, recall: 0.69, f1: 0.71, support: 90 },
    { class: 'Chemical staining', precision: 0.71, recall: 0.65, f1: 0.68, support: 95 },
    { class: 'Active seepage', precision: 0.77, recall: 0.76, f1: 0.76, support: 100 }
  ];

  const missionPoints = [
    {
      icon: Shield,
      title: 'Risk Mitigation',
      description: 'Preemptive anomaly detection prevents catastrophic failure cascades and secures long-term asset viability.'
    },
    {
      icon: Zap,
      title: 'Operational Velocity',
      description: 'Compress manual field inspection cycles from days to minutes, optimizing workforce allocation.'
    },
    {
      icon: Brain,
      title: 'Augmented Engineering',
      description: 'Statistical baselines and deterministic modeling provide engineers with verifiable secondary opinions.'
    },
    {
      icon: TrendingUp,
      title: 'Lifecycle Economics',
      description: 'Predictive analytics transition maintenance from reactive to proactive, drastically reducing capital expenditure.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Technical Architecture | ConstructGuard AI</title>
        <meta name="description" content="Explore the neural network architecture, validation metrics, and core technology behind our structural analysis platform." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="pt-32 pb-20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[hsl(var(--accent-blue))]/5 rounded-full blur-[100px] pointer-events-none"></div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-center mb-16 pt-12"
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass border-white/10 mb-8 mx-auto">
                  <Eye className="w-4 h-4 text-[hsl(var(--accent-blue))]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">System Architecture</span>
                </div>
                
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-foreground mb-8 tracking-tight text-balance max-w-4xl mx-auto">
                  Built on deterministic AI models.
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  ConstructGuard AI integrates computer vision, large language models, and statistical interpretability modules for production-grade accuracy.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-24 bg-black/20 border-y border-white/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mb-16"
              >
                <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4 tracking-tight">
                  Stack Components
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl">
                  A multi-modal approach to defect processing.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {technologies.map((tech, index) => (
                  <FeatureCard key={index} {...tech} index={index} />
                ))}
              </div>
            </div>
          </section>

          <section className="py-24">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mb-16"
              >
                <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4 tracking-tight">
                  Validation Telemetry
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl">
                  Benchmark performance evaluated against strict engineering control sets.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="glass rounded-xl overflow-hidden mb-12 premium-shadow"
              >
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[700px] text-left border-collapse">
                    <thead>
                      <tr className="bg-white/5 border-b border-white/10">
                        <th className="px-6 py-5 text-sm font-bold text-foreground tracking-wide uppercase">Taxonomy Class</th>
                        <th className="px-6 py-5 text-sm font-bold text-foreground tracking-wide uppercase text-center">Precision</th>
                        <th className="px-6 py-5 text-sm font-bold text-foreground tracking-wide uppercase text-center">Recall</th>
                        <th className="px-6 py-5 text-sm font-bold text-foreground tracking-wide uppercase text-center">F1-Score</th>
                        <th className="px-6 py-5 text-sm font-bold text-foreground tracking-wide uppercase text-center">Volume</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {classificationReport.map((row, index) => (
                        <tr key={index} className="hover:bg-white/[0.02] transition-colors">
                          <td className="px-6 py-4 text-sm font-semibold text-foreground">{row.class}</td>
                          <td className="px-6 py-4 text-sm text-center text-muted-foreground tabular-nums">
                            {row.precision.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-center text-muted-foreground tabular-nums">
                            {row.recall.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-center text-muted-foreground tabular-nums">
                            {row.f1.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-center text-muted-foreground tabular-nums">
                            {row.support}
                          </td>
                        </tr>
                      ))}
                      
                      {/* Summary Rows */}
                      <tr className="border-t border-white/10 bg-white/5">
                        <td className="px-6 py-5 text-sm font-bold text-foreground">Global Accuracy</td>
                        <td colSpan={2}></td>
                        <td className="px-6 py-5 text-sm text-center font-extrabold text-[hsl(var(--accent-blue))] tabular-nums">
                          0.76
                        </td>
                        <td className="px-6 py-5 text-sm text-center font-medium text-muted-foreground tabular-nums">
                          915
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </motion.div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="glass rounded-xl p-6 flex flex-col premium-shadow"
                >
                  <div className="flex-1 bg-[#050B14] rounded-lg overflow-hidden mb-6 flex items-center justify-center p-2 border border-white/5">
                    <img 
                      src="https://horizons-cdn.hostinger.com/44c53d15-d884-43f1-bc08-5530aea59e44/6657ee55a0e765f1c1d4d5ba09eb3fed.jpg" 
                      alt="Confusion Matrix of Cascaded AI Model Validation Results" 
                      className="w-full h-auto max-h-[350px] object-contain rounded-md"
                    />
                  </div>
                  <p className="text-xs font-bold text-center text-muted-foreground tracking-wider uppercase">
                    Class-wise Matrix Distribution
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 }}
                  className="glass rounded-xl p-6 flex flex-col premium-shadow"
                >
                  <div className="flex-1 bg-[#050B14] rounded-lg overflow-hidden mb-6 flex items-center justify-center p-2 border border-white/5">
                    <img 
                      src="https://horizons-cdn.hostinger.com/44c53d15-d884-43f1-bc08-5530aea59e44/0b9ac08571f2df592fdb822f961ffe76.jpg" 
                      alt="Kernel Density Estimation (KDE) Analysis of Model Performance" 
                      className="w-full h-auto max-h-[350px] object-contain rounded-md"
                    />
                  </div>
                  <p className="text-xs font-bold text-center text-muted-foreground tracking-wider uppercase">
                    Confidence Density Estimation
                  </p>
                </motion.div>
              </div>
            </div>
          </section>

          <section className="py-24 bg-black/20 border-t border-white/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mb-16"
              >
                <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4 tracking-tight">
                  Strategic Mandate
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl">
                  Automating safety infrastructure.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {missionPoints.map((point, index) => (
                  <FeatureCard key={index} {...point} index={index} />
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;

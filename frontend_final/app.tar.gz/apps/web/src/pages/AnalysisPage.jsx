
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Upload, Image as ImageIcon, AlertTriangle, Info, Activity, 
  FileText, ShieldAlert, Wrench, BarChart3, CheckCircle,
  Clock, RefreshCw, ChevronDown, Settings, XCircle, Loader2, Scan,
  ListChecks, ShieldCheck
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useToast } from '@/hooks/use-toast';
import { validateImageWithGemini, generateReportWithGemini } from '@/hooks/useGeminiAPI.js';

const detailedDefectData = {
  'Algae': { severity: 'Low', confidence: 93.5 },
  'Major crack': { severity: 'Critical', confidence: 96.8 },
  'Minor crack': { severity: 'Moderate', confidence: 94.2 },
  'Mold': { severity: 'High', confidence: 97.3 },
  'Peeling paint': { severity: 'Low', confidence: 92.4 },
  'Spalling': { severity: 'Critical', confidence: 98.1 },
  'Stain': { severity: 'Moderate', confidence: 91.8 },
  'Water seepage': { severity: 'High', confidence: 95.7 },
  'Healthy surface': { severity: 'Low', confidence: 99.2 }
};

const ExpandableSection = ({ title, icon: Icon, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="report-section mb-3">
      <button 
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="report-section-header group"
      >
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-md bg-white/5 group-hover:bg-white/10 transition-colors border border-white/10">
            <Icon className="w-4 h-4 text-[hsl(var(--accent-blue))]" />
          </div>
          <span className="text-sm font-semibold tracking-wide">{title}</span>
        </div>
        <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="report-section-content text-sm pt-2">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const AnalysisGuidelines = () => {
  const guidelines = [
    "Ensure image is well-lit using natural or even artificial light.",
    "Avoid blurry shots; maintain sharp focus on the structural surface.",
    "Center the primary defect clearly within the camera frame.",
    "Include surrounding context (avoid extreme close-ups without baseline).",
    "Shoot perpendicular to the surface to minimize perspective distortion.",
    "Minimize harsh shadows, glare, or reflections on the target area.",
    "Crack Detection: Capture both ends of the fracture if possible.",
    "Water Seepage: Ensure moisture boundaries or stains are visible.",
    "Keep the line of sight clear of physical obstructions (e.g., foliage, equipment).",
    "Maintain an optimal capture distance of 1 to 2 meters.",
    "Use high-resolution image sensors (1080p minimum recommended).",
    "Supported formats exclusively: JPG, JPEG, and PNG."
  ];

  const categories = [
    "Algae", "Mold", "Major Crack", "Minor Crack", "Peeling Paint", 
    "Spalling", "Stain", "Water Seepage", "Healthy Surface"
  ];

  return (
    <div className="glass rounded-2xl p-6 mb-6 premium-shadow border border-white/10 relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-[hsl(var(--accent-blue))]/10 rounded-full blur-2xl"></div>
      
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-[hsl(var(--accent-blue))]/10 flex items-center justify-center border border-[hsl(var(--accent-blue))]/20">
          <Info className="w-5 h-5 text-[hsl(var(--accent-blue))]" />
        </div>
        <div>
          <h2 className="text-base font-bold text-foreground tracking-wide">Analysis Guidelines</h2>
          <p className="text-xs text-muted-foreground">Guidelines for Best Results</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="text-xs font-bold text-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <ListChecks className="w-3.5 h-3.5 text-muted-foreground" /> Capture Protocol
          </h3>
          <div className="grid grid-cols-1 gap-2 pl-1">
            {guidelines.map((text, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <span className="text-[10px] font-bold text-[hsl(var(--accent-blue))] bg-[hsl(var(--accent-blue))]/10 w-4 h-4 rounded flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <p className="text-xs text-muted-foreground leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-white/5">
          <h3 className="text-xs font-bold text-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-muted-foreground" /> Supported Categories
          </h3>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat, i) => (
              <span key={i} className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider bg-white/5 border border-white/10 px-2 py-1 rounded-md">
                {cat}
              </span>
            ))}
          </div>
        </div>

        <div className="bg-[hsl(var(--accent-blue))]/10 border border-[hsl(var(--accent-blue))]/20 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-[hsl(var(--accent-blue))] shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-bold text-[hsl(var(--accent-blue))] uppercase tracking-wider mb-1">Important Notice</h4>
            <p className="text-[10px] text-[hsl(var(--accent-blue))]/80 leading-relaxed">
              AI-assisted diagnostics provide statistical probabilities based on visual vectors. Final structural validation and remediation planning must be conducted by licensed engineering professionals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const AnalysisPage = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  
  // Workflow States: 'idle' | 'validating_image' | 'analyzing_defect' | 'generating_report' | 'complete' | 'error'
  const [workflowState, setWorkflowState] = useState('idle');
  const [errorMessage, setErrorMessage] = useState('');
  
  const [predictionResult, setPredictionResult] = useState(null);
  const [generatedReport, setGeneratedReport] = useState(null);
  
  const { toast } = useToast();

  const handleImageSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: 'Invalid format',
          description: 'System strictly requires JPG, PNG, or JPEG visual data.',
          variant: 'destructive'
        });
        return;
      }
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
      resetAnalysis();
    }
  };

  const resetAnalysis = () => {
    setWorkflowState('idle');
    setErrorMessage('');
    setPredictionResult(null);
    setGeneratedReport(null);
  };

  const openSettings = () => {
    window.dispatchEvent(new CustomEvent('open-settings'));
  };

  const executeAnalysisFlow = async () => {
    if (!selectedImage) return;

    const apiKey = localStorage.getItem('gemini_api_key') || '';

    try {
      setWorkflowState('validating_image');
      const validation = await validateImageWithGemini(selectedImage, apiKey);
      
      if (validation.status === 'error') {
        setErrorMessage(`Ingestion rejected: ${validation.error}`);
        setWorkflowState('error');
        return;
      }
      
      if (!validation.data?.isValid) {
        setErrorMessage(`Irrelevant asset context: ${validation.data?.reason || 'Unknown parameters.'} Upload valid structural or architectural imagery.`);
        setWorkflowState('error');
        return;
      }

      setWorkflowState('analyzing_defect');
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const defectTypes = Object.keys(detailedDefectData);
      const randomDefect = defectTypes[Math.floor(Math.random() * defectTypes.length)];
      const baseData = detailedDefectData[randomDefect];
      
      const prediction = {
        defectName: randomDefect,
        severity: baseData.severity,
        confidence: baseData.confidence,
        timestamp: new Date().toISOString()
      };
      setPredictionResult(prediction);

      setWorkflowState('generating_report');
      const reportResponse = await generateReportWithGemini(
        selectedImage, 
        prediction, 
        apiKey
      );

      if (reportResponse.status === 'error') {
        setErrorMessage('Report synthesizer disconnected. Visual classifications retained.');
        setWorkflowState('complete');
        toast({
          title: 'Synthesis Error',
          description: reportResponse.error,
          variant: 'destructive'
        });
        return;
      }

      setGeneratedReport(reportResponse.data);
      setWorkflowState('complete');
      toast({
        title: 'Diagnostic Complete',
        description: `Classified anomaly: ${randomDefect}. Report ready.`
      });

    } catch (error) {
      setErrorMessage(error.message || 'Model disconnected. Verify API configuration keys in system settings.');
      setWorkflowState('error');
    }
  };

  const getSeverityBadgeClass = (severity) => {
    switch(severity) {
      case 'Critical': return 'bg-destructive/20 text-destructive border-destructive/30';
      case 'High': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'Moderate': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'Low': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      default: return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    }
  };

  const getSeverityProgressClass = (severity) => {
    switch(severity) {
      case 'Critical': return 'bg-destructive';
      case 'High': return 'bg-orange-500';
      case 'Moderate': return 'bg-yellow-500';
      case 'Low': return 'bg-emerald-500';
      default: return 'bg-emerald-500';
    }
  };

  return (
    <>
      <Helmet>
        <title>Diagnostics Workspace | ConstructGuard AI</title>
        <meta name="description" content="Secure portal for uploading structural imagery and generating automated defect classifications." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 pt-32 pb-24 relative overflow-hidden">
          <div className="absolute top-1/4 -right-64 w-[800px] h-[800px] bg-[hsl(var(--accent-blue))]/5 rounded-full blur-[120px] pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-12"
            >
              <h1 className="text-3xl md:text-4xl font-extrabold text-foreground mb-3 tracking-tight">
                Diagnostics Workspace
              </h1>
              <p className="text-base text-muted-foreground">
                Run proprietary vision classifications on structural surface assets.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* LEFT COLUMN: Upload & Actions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="lg:col-span-4 flex flex-col"
              >
                <AnalysisGuidelines />
                
                <div className="glass p-6 rounded-2xl flex flex-col premium-shadow border border-white/10 flex-1">
                  <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
                    <h2 className="text-sm font-bold text-foreground uppercase tracking-wider flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-[hsl(var(--accent-blue))]" /> Target Asset
                    </h2>
                  </div>
                  
                  {!selectedImage ? (
                    <div className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center hover:border-[hsl(var(--accent-blue))]/50 transition-colors cursor-pointer bg-black/20 flex-1 flex flex-col items-center justify-center group relative overflow-hidden min-h-[250px]">
                      <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--accent-blue))]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/jpg"
                        onChange={handleImageSelect}
                        className="hidden"
                        id="image-upload"
                      />
                      <label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center w-full h-full justify-center relative z-10">
                        <div className="w-16 h-16 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4 transition-transform group-hover:scale-105 group-hover:bg-white/10 premium-shadow">
                          <Upload className="w-8 h-8 text-[hsl(var(--accent-blue))]" />
                        </div>
                        <p className="text-foreground font-bold mb-1 text-base tracking-wide">
                          Mount Data File
                        </p>
                        <p className="text-xs text-muted-foreground mb-4 font-medium">
                          Select or drag structure image
                        </p>
                        <span className="text-[10px] uppercase tracking-widest font-bold bg-white/10 px-2 py-1 rounded border border-white/5">JPG / PNG</span>
                      </label>
                    </div>
                  ) : (
                    <div className="flex flex-col flex-1 min-h-[250px]">
                      <div className="rounded-xl overflow-hidden border border-white/10 bg-[#050B14] flex-1 relative flex items-center justify-center p-2 shadow-inner">
                        <img
                          src={imagePreview}
                          alt="Asset pending structural verification"
                          className="w-full h-auto max-h-[350px] object-contain rounded-lg"
                        />
                      </div>
                      <div className="mt-4">
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/jpg"
                          onChange={handleImageSelect}
                          className="hidden"
                          id="image-change"
                        />
                        <label htmlFor="image-change">
                          <button className="w-full py-3 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-sm font-semibold transition-colors flex items-center justify-center gap-2">
                            <RefreshCw className="w-4 h-4" /> Swap Asset
                          </button>
                        </label>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={executeAnalysisFlow}
                    disabled={!selectedImage || ['validating_image', 'analyzing_defect', 'generating_report'].includes(workflowState)}
                    className={`w-full mt-6 py-4 rounded-xl text-sm font-bold tracking-wide flex items-center justify-center ${
                      !selectedImage || ['validating_image', 'analyzing_defect', 'generating_report'].includes(workflowState)
                        ? 'bg-white/5 text-muted-foreground cursor-not-allowed border border-white/5'
                        : 'gradient-primary premium-shadow'
                    }`}
                  >
                    {workflowState === 'validating_image' ? 'VERIFYING ASSET...' :
                     workflowState === 'analyzing_defect' ? 'RUNNING MODELS...' :
                     workflowState === 'generating_report' ? 'SYNTHESIZING...' :
                     'EXECUTE DIAGNOSTICS'}
                  </button>
                </div>
              </motion.div>

              {/* RIGHT COLUMN: Output Telemetry */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-8"
              >
                <div className="glass p-6 md:p-8 rounded-2xl h-full border border-white/10 premium-shadow min-h-[600px]">
                  <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
                    <h2 className="text-sm font-bold text-foreground uppercase tracking-wider flex items-center gap-2">
                      <Activity className="w-4 h-4 text-[hsl(var(--accent-violet))]" /> Telemetry Output
                    </h2>
                    {workflowState === 'complete' && (
                      <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20 uppercase tracking-widest">
                        <CheckCircle className="w-3 h-3"/> Standby
                      </span>
                    )}
                  </div>

                  {workflowState === 'idle' && !errorMessage && (
                    <div className="flex flex-col items-center justify-center h-[500px] text-center">
                      <div className="w-20 h-20 rounded-2xl bg-white/5 flex items-center justify-center mb-6 border border-white/10">
                        <Scan className="w-8 h-8 text-muted-foreground/50" />
                      </div>
                      <h3 className="text-base font-bold text-foreground mb-2">Awaiting Input Stream</h3>
                      <p className="text-sm text-muted-foreground max-w-sm">
                        Mount visual data to initialize the classification pipeline. Review the guidelines for optimal results.
                      </p>
                    </div>
                  )}

                  {workflowState === 'error' && (
                    <div className="flex flex-col items-center justify-center h-[500px] text-center animate-status-fade-in">
                      <div className="w-16 h-16 rounded-2xl bg-rose-500/10 flex items-center justify-center mb-6 border border-rose-500/20">
                        <XCircle className="w-8 h-8 text-rose-500" />
                      </div>
                      <h3 className="text-base font-bold text-foreground mb-3">Pipeline Interrupted</h3>
                      <div className="bg-rose-500/10 border border-rose-500/20 text-rose-200 text-sm p-4 rounded-lg max-w-lg mb-8">
                        {errorMessage}
                      </div>
                      <div className="flex gap-4">
                        <button onClick={openSettings} className="px-6 py-2.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-sm font-semibold flex items-center gap-2 transition-colors">
                          <Settings className="w-4 h-4" /> Config
                        </button>
                        <button onClick={executeAnalysisFlow} className="px-6 py-2.5 rounded-lg gradient-primary text-sm font-semibold flex items-center gap-2 premium-shadow">
                          <RefreshCw className="w-4 h-4" /> Retry
                        </button>
                      </div>
                    </div>
                  )}

                  {['validating_image', 'analyzing_defect', 'generating_report'].includes(workflowState) && (
                    <div className="flex flex-col items-center justify-center h-[500px] text-center space-y-8 animate-status-fade-in">
                      <div className="relative w-20 h-20 flex items-center justify-center">
                        <div className="absolute inset-0 rounded-full border-2 border-white/5"></div>
                        <div className="absolute inset-0 rounded-full border-2 border-[hsl(var(--accent-blue))] border-t-transparent animate-spin-slow"></div>
                        <div className="absolute inset-3 rounded-full border-2 border-[hsl(var(--accent-violet))] border-b-transparent animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '2s' }}></div>
                        <Loader2 className="w-6 h-6 text-white animate-pulse" />
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-bold text-foreground tracking-widest uppercase">
                          {workflowState === 'validating_image' ? 'Context Validation...' :
                           workflowState === 'analyzing_defect' ? 'CNN Processing...' :
                           'LLM Synthesis...'}
                        </p>
                        <p className="text-xs text-muted-foreground flex items-center justify-center gap-2 font-mono">
                          <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--accent-blue))] animate-pulse"></span>
                          COMPUTING_VECTORS
                        </p>
                      </div>
                    </div>
                  )}

                  {workflowState === 'complete' && predictionResult && (
                    <div className="space-y-6 animate-status-fade-in pb-4">
                      {errorMessage && (
                        <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 p-4 rounded-xl flex items-start gap-3 mb-6">
                          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                          <p className="text-sm font-medium">{errorMessage}</p>
                        </div>
                      )}

                      {/* Primary Diagnostic Card */}
                      <div className="bg-[#0A101C] border border-white/10 rounded-2xl p-6 relative overflow-hidden premium-shadow">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-blue))]/10 rounded-bl-full -z-10 blur-2xl"></div>
                        
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-8">
                          <div>
                            <p className="text-[10px] font-bold text-muted-foreground mb-2 uppercase tracking-widest">Primary Classification</p>
                            <h3 className="text-2xl font-extrabold text-foreground tracking-tight">{predictionResult.defectName}</h3>
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <span className={`px-3 py-1 text-xs font-bold uppercase tracking-widest rounded border ${getSeverityBadgeClass(predictionResult.severity)}`}>
                              {predictionResult.severity}
                            </span>
                            <div className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground">
                              <Clock className="w-3 h-3" />
                              {new Date(predictionResult.timestamp).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>

                        <div className="pt-5 border-t border-white/5">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                              <BarChart3 className="w-3.5 h-3.5" /> Probability Index
                            </span>
                            <span className="text-base font-extrabold text-foreground font-mono">{predictionResult.confidence}%</span>
                          </div>
                          <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${predictionResult.confidence}%` }}
                              transition={{ duration: 1.2, ease: "easeOut" }}
                              className={`h-full ${getSeverityProgressClass(predictionResult.severity)}`}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Generated Text Vectors */}
                      {generatedReport && (
                        <div className="mt-8 space-y-1">
                          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2 px-1">
                            <FileText className="w-4 h-4 text-[hsl(var(--accent-violet))]" /> 
                            Synthesized Output
                          </h3>
                          
                          {generatedReport['Executive Summary'] && (
                            <div className="bg-[hsl(var(--accent-blue))]/5 border border-[hsl(var(--accent-blue))]/20 rounded-xl p-5 mb-4">
                              <h4 className="text-[10px] font-bold text-[hsl(var(--accent-blue))] uppercase tracking-widest mb-2">Executive Summary</h4>
                              <p className="text-sm text-foreground leading-relaxed">
                                {generatedReport['Executive Summary']}
                              </p>
                            </div>
                          )}

                          <div className="space-y-0 text-sm">
                            {generatedReport['Defect Description'] && (
                              <ExpandableSection title="Topological Description" icon={Info} defaultOpen={true}>
                                {generatedReport['Defect Description']}
                              </ExpandableSection>
                            )}
                            
                            {generatedReport['Severity Assessment'] && (
                              <ExpandableSection title="Calculated Severity" icon={AlertTriangle} defaultOpen={true}>
                                {generatedReport['Severity Assessment']}
                              </ExpandableSection>
                            )}
                            
                            {generatedReport['Structural Impact'] && (
                              <ExpandableSection title="Asset Impact" icon={ShieldAlert}>
                                {generatedReport['Structural Impact']}
                              </ExpandableSection>
                            )}
                            
                            {generatedReport['Recommended Actions'] && (
                              <ExpandableSection title="Remediation Protocol" icon={Wrench}>
                                {generatedReport['Recommended Actions']}
                              </ExpandableSection>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Legal Footer */}
                      <div className="mt-6 pt-4 border-t border-white/5">
                        <p className="text-[10px] text-muted-foreground leading-relaxed text-justify font-mono opacity-60 hover:opacity-100 transition-opacity">
                          <strong className="uppercase tracking-widest mr-2 text-foreground">Disclaimer:</strong> 
                          Output generated by unsupervised neural networks. Determinations are statistical probabilities, not binding engineering certifications. Final sign-off must be executed by licensed professionals.
                        </p>
                      </div>

                    </div>
                  )}
                </div>
              </motion.div>

            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default AnalysisPage;
